# Build the Samurai Clock APK on GitHub (no laptop)

1. Create a GitHub repository (public or private) named `SamuraiClockLiveWallpaper`.
2. Extract this ZIP on your phone. Open the `SamuraiClockLiveWallpaper` folder.
3. In the repository, choose **Add file → Upload files** and upload the *contents* of this folder, including the hidden `.github` folder. Do not upload this ZIP as one file.
4. Commit the upload to the `main` branch.
5. Open the repository's **Actions** tab. The workflow **Build Samurai Clock APK** should start automatically.
6. When it finishes successfully, open the run and download the `SamuraiClock-debug-apk` artifact. GitHub may ask you to sign in.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk` on your phone.

The workflow uses GitHub-hosted runners, Java 17, and Gradle 8.9. The APK is a debug build for testing, not a Play Store release.
