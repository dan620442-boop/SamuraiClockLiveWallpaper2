# Samurai Clock Live Wallpaper — Version 2.0

An Android live wallpaper using the supplied samurai / crimson cherry-blossom artwork, with a large live digital clock.

## Version 2 clock design

- Large `HH:mm` 24-hour clock (for example, `18:42`), regardless of the phone's 12/24-hour preference.
- White hour/minute digits with a crimson-red colon.
- Date displayed beneath the time.
- Subtle translucent dark panel with a fine crimson outline for legibility over the pale sky.
- Clock positioned slightly right of centre in the open sky beneath the blossom canopy, clear of the samurai's face and hat.
- Refreshes at the next minute boundary while the wallpaper is visible; no drawing while hidden.

## Build and install

1. Open this folder in Android Studio (Giraffe or newer; current stable is recommended).
2. Allow Gradle sync to download the Android Gradle Plugin and SDK components.
3. Connect your Motorola Edge 70 Fusion with USB debugging enabled, or select an emulator.
4. Run the `app` configuration.
5. Tap **Preview and set wallpaper**, then choose Home screen, Lock screen, or both if Android offers that choice.

To build an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK will be under `app/build/outputs/apk/debug/`.

## Requirements and permissions

- Android minSdk 23; compileSdk 35.
- No internet, location, storage, or other runtime permissions.
- Uses Android's native `WallpaperService` and local device time.

## Layout adjustment

The clock is placed at approximately 28.5% of the wallpaper's visible height and 66% of its width. If your launcher crops the artwork differently, adjust `centerX` and `timeBaseline` in `SamuraiWallpaperService.java`.
