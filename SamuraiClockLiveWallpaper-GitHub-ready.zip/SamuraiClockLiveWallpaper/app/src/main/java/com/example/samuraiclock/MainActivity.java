package com.example.samuraiclock;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(32, 32, 32, 32);
        layout.setBackgroundColor(0xFF101010);

        TextView title = new TextView(this);
        title.setText("SAMURAI CLOCK\nLIVE WALLPAPER");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        layout.addView(title);

        TextView detail = new TextView(this);
        detail.setText("Large 24-hour digital clock with white digits, a crimson colon, and your cherry-blossom samurai artwork.");
        detail.setTextColor(0xFFCCCCCC);
        detail.setTextSize(16);
        detail.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(0, 24, 0, 32);
        layout.addView(detail, dp);

        Button button = new Button(this);
        button.setText("Preview and set wallpaper");
        button.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    new ComponentName(this, SamuraiWallpaperService.class));
            startActivity(intent);
        });
        layout.addView(button);

        TextView note = new TextView(this);
        note.setText("Choose whether to apply it to the Home screen, Lock screen, or both when Android asks.");
        note.setTextColor(0xFFAAAAAA);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, 24, 0, 0);
        layout.addView(note, np);
        setContentView(layout);
    }
}
