package com.example.samuraiclock;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SamuraiWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new SamuraiEngine(); }

    private class SamuraiEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable drawRunnable = this::drawFrame;
        private Bitmap artwork;
        private boolean visible;
        private final Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint shadowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint timePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final Paint datePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final Paint accentPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint panelStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);

        SamuraiEngine() {
            artwork = BitmapFactory.decodeResource(getResources(), R.drawable.samurai_wallpaper);
            timePaint.setColor(Color.WHITE);
            timePaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            timePaint.setTextAlign(Paint.Align.LEFT);
            timePaint.setShadowLayer(5f, 0f, 2f, 0xCC000000);
            accentPaint.setColor(0xFFFF3434);
            accentPaint.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
            accentPaint.setTextAlign(Paint.Align.LEFT);
            accentPaint.setShadowLayer(5f, 0f, 2f, 0xCC000000);
            datePaint.setColor(0xFFF5F0EC);
            datePaint.setTypeface(Typeface.create("sans-serif", Typeface.MEDIUM));
            datePaint.setTextAlign(Paint.Align.CENTER);
            datePaint.setShadowLayer(6f, 0f, 2f, 0xCC000000);
            shadowPaint.setColor(0x770B0B0B);
            shadowPaint.setStyle(Paint.Style.FILL);
            panelStrokePaint.setColor(0x99D92727);
            panelStrokePaint.setStyle(Paint.Style.STROKE);
            panelStrokePaint.setStrokeWidth(2f);
        }

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            handler.removeCallbacks(drawRunnable);
            if (visible) drawFrame();
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            super.onSurfaceDestroyed(holder);
        }

        @Override public void onDestroy() {
            visible = false;
            handler.removeCallbacks(drawRunnable);
            if (artwork != null && !artwork.isRecycled()) artwork.recycle();
            super.onDestroy();
        }

        private void drawFrame() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas();
                if (canvas != null) {
                    int w = canvas.getWidth();
                    int h = canvas.getHeight();
                    canvas.drawColor(Color.BLACK);
                    if (artwork != null) {
                        float scale = Math.max((float) w / artwork.getWidth(), (float) h / artwork.getHeight());
                        float dw = artwork.getWidth() * scale;
                        float dh = artwork.getHeight() * scale;
                        float left = (w - dw) / 2f;
                        float top = (h - dh) / 2f;
                        canvas.drawBitmap(artwork, null, new RectF(left, top, left + dw, top + dh), imagePaint);
                    }
                    drawClock(canvas, w, h);
                }
            } catch (Exception ignored) {
                // The system may destroy the surface while a frame is being drawn.
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas);
            }
            // Update once per minute; do no drawing while the wallpaper is hidden.
            long now = System.currentTimeMillis();
            long delay = 60_000L - (now % 60_000L) + 80L;
            handler.removeCallbacks(drawRunnable);
            if (visible) handler.postDelayed(drawRunnable, delay);
        }

        private void drawClock(Canvas canvas, int w, int h) {
            Date now = new Date();
            // Explicit 24-hour clock, independent of the phone's 12/24-hour preference.
            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now);
            String date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(now);
            String hours = time.substring(0, 2);
            String minutes = time.substring(3, 5);

            // Place the clock in the open sky, slightly right of centre, below the canopy.
            float centerX = w * 0.66f;
            float timeBaseline = h * 0.285f;
            float timeSize = Math.min(w * 0.155f, h * 0.070f);
            timePaint.setTextSize(timeSize);
            accentPaint.setTextSize(timeSize);
            datePaint.setTextSize(Math.max(15f, w * 0.032f));

            float hoursWidth = timePaint.measureText(hours);
            float colonWidth = accentPaint.measureText(":");
            float minutesWidth = timePaint.measureText(minutes);
            float totalWidth = hoursWidth + colonWidth + minutesWidth;
            float startX = centerX - totalWidth / 2f;
            float dateWidth = datePaint.measureText(date);
            float panelWidth = Math.min(w * 0.82f, Math.max(totalWidth + w * 0.12f, dateWidth + w * 0.12f));
            float panelTop = timeBaseline - timeSize * 1.13f;
            float panelBottom = timeBaseline + timeSize * 1.08f;
            RectF panel = new RectF(centerX - panelWidth / 2f, panelTop,
                    centerX + panelWidth / 2f, panelBottom);
            float radius = timeSize * 0.28f;
            canvas.drawRoundRect(panel, radius, radius, shadowPaint);
            canvas.drawRoundRect(panel, radius, radius, panelStrokePaint);

            float x = startX;
            canvas.drawText(hours, x, timeBaseline, timePaint);
            x += hoursWidth;
            canvas.drawText(":", x, timeBaseline, accentPaint);
            x += colonWidth;
            canvas.drawText(minutes, x, timeBaseline, timePaint);

            datePaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText(date, centerX, timeBaseline + timeSize * 0.78f, datePaint);
            datePaint.setTextAlign(Paint.Align.CENTER);
        }

    }
}
